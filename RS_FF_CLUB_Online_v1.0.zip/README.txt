RS FF CLUB Online v1.0
========================
This is the first frontend prototype.

Included:
- Login/Register UI (local demo only)
- Home/dashboard
- Games: Free Fire Match, Tournament, Survival Match, Esports Pro League, Ludo
- Wallet UI
- Topup/Withdraw UI
- Profile
- Mobile responsive design

Important:
The login, wallet, topup and withdraw logic in this first version is LOCAL DEMO logic using browser localStorage.
It is NOT a real payment/authentication system yet.

Next production step:
Connect Firebase/Supabase backend, real authentication, database, server-side wallet ledger and payment verification.
Never put Firebase service-account private keys in frontend files.
